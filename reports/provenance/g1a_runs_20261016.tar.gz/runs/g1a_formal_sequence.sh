#!/bin/zsh
# G1a formal sequence: 5 independent eager processes, then one process with eager+compile. Sequential: never two GPU jobs.
cd "$(dirname "$0")/.."
source .venv/bin/activate
echo "sequence start $(date -u +%FT%TZ) pid $$" > runs/g1a-formal.pids
for i in 1 2 3 4 5; do
  echo "=== process p$i start $(date -u +%FT%TZ)"
  caffeinate -i python bench/microbench.py --modes eager --tag p$i &
  echo "p$i $!" >> runs/g1a-formal.pids; wait $!
  echo "=== process p$i exit $? $(date -u +%FT%TZ)"
done
echo "=== process compile start $(date -u +%FT%TZ)"
caffeinate -i python bench/microbench.py --modes eager compile --skip-diagnostics --tag compile &
echo "compile $!" >> runs/g1a-formal.pids; wait $!
echo "=== process compile exit $? $(date -u +%FT%TZ)"
echo "sequence end $(date -u +%FT%TZ)" >> runs/g1a-formal.pids
