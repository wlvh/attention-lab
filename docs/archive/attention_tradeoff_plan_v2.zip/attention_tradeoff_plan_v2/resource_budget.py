#!/usr/bin/env python3
"""Payload and cloud-budget arithmetic only; never rents or terminates a machine.

Uses a stated Qwen3 architecture model, not measured peak memory or performance.
All memory outputs use GiB = 2**30 bytes. GPU/RAM quotes use vendor labels.
"""
from __future__ import annotations
import argparse
import json
import math
from decimal import Decimal
from pathlib import Path

MODELS = {
    '0.6b': dict(layers=28, hidden=1024, q_heads=16, kv_heads=8,
                 head_dim=128, intermediate=3072, vocab=151936),
    '4b': dict(layers=36, hidden=2560, q_heads=32, kv_heads=8,
               head_dim=128, intermediate=9728, vocab=151936),
}

def positive_int(n: int, name: str) -> int:
    if isinstance(n, bool) or not isinstance(n, int) or n < 1:
        raise ValueError(f'{name} must be a positive integer')
    return n

def parameter_count(c: dict[str, int]) -> int:
    # Bias-free Q/K/V/O and SwiGLU; two per-layer RMSNorms, Q/K head norms;
    # embedding and vocabulary head tied; final RMSNorm.
    h, q, k, d, f, l, v = (c[x] for x in
        ('hidden', 'q_heads', 'kv_heads', 'head_dim', 'intermediate', 'layers', 'vocab'))
    return v*h + l*(2*h*q*d + 2*h*k*d + 3*h*f + 2*h + 2*d) + h

def memory_ledger(model: str, tokens: int, batch: int = 1, rank: int = 32,
                  weight_bytes: int = 2, kv_bytes: int = 2,
                  index_bytes: int = 2, trace_rows: int = 8) -> dict:
    if model not in MODELS:
        raise ValueError('Unknown model')
    for name, n in locals().copy().items():
        if name not in ('model',):
            positive_int(n, name)
    c = MODELS[model]
    l, q, g, d = (c[k] for k in ('layers', 'q_heads', 'kv_heads', 'head_dim'))
    params = parameter_count(c)
    weights = params*weight_bytes
    kv = 2*l*batch*tokens*g*d*kv_bytes
    index = l*batch*tokens*g*rank*index_bytes
    index_params = l*(q+g)*d*rank  # group-concatenated Q projection + K projection, no bias
    score_one = batch*q*tokens*tokens*4
    trace_one = batch*q*min(trace_rows, tokens)*tokens*4
    payload = weights + kv + index + index_params*weight_bytes
    return {
        'model': model, 'tokens': tokens, 'batch': batch, 'index_rank': rank,
        'calculated_parameters': params, 'index_parameters_without_temperature': index_params,
        'weights_gib': weights/2**30, 'kv_gib': kv/2**30,
        'index_cache_gib': index/2**30,
        'index_weights_gib': index_params*weight_bytes/2**30,
        'one_live_request_payload_gib': payload/2**30,
        'one_layer_full_fp32_scores_gib': score_one/2**30,
        'all_layers_full_fp32_scores_gib': score_one*l/2**30,
        'one_layer_sampled_fp32_scores_gib': trace_one/2**30,
        'warning': 'Payload arithmetic, NOT peak memory. Add workspaces, activations, allocator, '
                   'cache copies, and runtime. No attention scores need to be persisted for all layers. '
                   'A 32768-position ledger does not authorize 32768 input tokens plus output.',
    }

def D(value) -> Decimal:
    out = Decimal(str(value))
    if not out.is_finite() or out < 0:
        raise ValueError('Money and hours must be finite and nonnegative')
    return out

def cloud_budget(rate, hours, prior_compute=0, noncompute=10, tax_rate=0,
                 reserve=20, total_limit=100, compute_limit=70) -> dict:
    rate, hours, prior_compute, noncompute, tax_rate, reserve, total_limit, compute_limit = map(
        D, (rate, hours, prior_compute, noncompute, tax_rate, reserve, total_limit, compute_limit))
    if rate <= 0:
        raise ValueError('Rate must be positive')
    new_compute = rate*hours
    compute_total = prior_compute+new_compute
    base = compute_total+noncompute
    tax = base*tax_rate
    projected = base+tax
    remaining_compute = max(Decimal(0), compute_limit-prior_compute)
    remaining_spend = max(Decimal(0), (total_limit-reserve)/(1+tax_rate)-noncompute-prior_compute)
    max_hours = min(remaining_compute, remaining_spend)/rate
    allowed = compute_total <= compute_limit and projected+reserve <= total_limit
    return {'allowed_by_planning_limits': bool(allowed),
            'new_compute_usd': str(new_compute.quantize(Decimal('0.01'))),
            'cumulative_compute_usd': str(compute_total.quantize(Decimal('0.01'))),
            'projected_all_in_usd': str(projected.quantize(Decimal('0.01'))),
            'reserved_uncommitted_usd': str(reserve),
            'safe_additional_hours_at_quoted_rate': float(max_hours),
            'warning': 'Planning arithmetic only. Does NOT enforce provider billing. '
                       'Include all setup/idle time, all resources, storage and taxes; '
                       'verify checkout quote, disable auto-pay, set external termination, '
                       'export data before deletion. Never rely on exiting Python to stop billing.'}

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='cmd', required=True)
    m = sub.add_parser('memory')
    m.add_argument('--model', choices=MODELS, default='4b')
    m.add_argument('--tokens', type=int, default=8192)
    m.add_argument('--batch', type=int, default=1)
    m.add_argument('--rank', type=int, default=32)
    m.add_argument('--trace-rows', type=int, default=8)
    b = sub.add_parser('cloud')
    b.add_argument('--rate', required=True, help='Actual full-instance hourly compute quote')
    b.add_argument('--hours', required=True)
    b.add_argument('--prior-compute', default='0')
    b.add_argument('--noncompute', default='10', help='Known/upper-bound noncompute fees before tax')
    b.add_argument('--tax-rate', required=True, help='Explicit fraction; e.g. 0.1; 0 only after checking')
    args = vars(p.parse_args())
    cmd = args.pop('cmd')
    try:
        result = memory_ledger(**args) if cmd=='memory' else cloud_budget(**args)
    except (ValueError, ArithmeticError) as exc:
        p.error(str(exc))
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if cmd=='cloud' and not result['allowed_by_planning_limits']:
        raise SystemExit(2)

if __name__=='__main__':
    main()
