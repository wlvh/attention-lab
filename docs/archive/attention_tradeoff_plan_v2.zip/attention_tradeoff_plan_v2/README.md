# 注意力结构取舍实验：方案包 v2

先读 `PLAN.md`。本包是新的实施方案，不是已经完成的模型实验。

## 当前可运行的部分

仅资源与预算计算器，无网络、凭证、GPU需求；不创建或终止云资源。

```bash
python resource_budget.py memory --model 4b --tokens 8192 --rank 32
python resource_budget.py cloud --rate 5.29 --hours 10 --prior-compute 0 --noncompute 10 --tax-rate 0.1
python -m unittest -v
```

第二条的税率0.1是演示假设，必须替换为结算时实际适用税率；10小时是租用预算，不是完成时长预测。
预算被拒绝时脚本以状态码2结束。脚本通过不能替代云端计费保护。

## 文件

`PLAN.md` 为完整方案；`experiment_spec.json` 为待实现实验规格；`memory_ledger.json` 为公式计算而非实测；
`planner_test_results.txt` 为本包10项算账测试的结果，不是Transformer模型测试；`sources/` 保存来源与配置字段转录。

尚未下载或训练4B模型，没有GPU速度、准确率或峰值内存实测，没有租用任何云实例。

云端总费用上限100美元，预留20美元，不自动扩容、不自动充值。
