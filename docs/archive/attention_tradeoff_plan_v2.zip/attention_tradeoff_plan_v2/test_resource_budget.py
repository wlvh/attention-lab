import unittest
from resource_budget import memory_ledger, cloud_budget, parameter_count, MODELS

class BudgetTests(unittest.TestCase):
    def test_qwen_4b_kv_8k(self):
        r=memory_ledger('4b',8192)
        self.assertEqual(r['kv_gib'],1.125)
        self.assertEqual(r['index_cache_gib'],0.140625)
    def test_qwen_4b_kv_32k(self):
        r=memory_ledger('4b',32768)
        self.assertEqual(r['kv_gib'],4.5)
        self.assertEqual(r['index_cache_gib'],0.5625)
        self.assertEqual(r['all_layers_full_fp32_scores_gib'],4608.0)
        self.assertEqual(r['one_layer_sampled_fp32_scores_gib'],0.03125)
    def test_small_model(self):
        self.assertEqual(memory_ledger('0.6b',8192)['kv_gib'],0.875)
    def test_batch_scaling(self):
        self.assertEqual(memory_ledger('4b',8192,batch=2)['kv_gib'],2.25)
    def test_rank_scales_only_index(self):
        a=memory_ledger('4b',8192,rank=16);b=memory_ledger('4b',8192,rank=32)
        self.assertEqual(a['index_cache_gib']*2,b['index_cache_gib'])
        self.assertEqual(a['kv_gib'],b['kv_gib'])
    def test_invalid(self):
        for n in (0,-1):
            with self.assertRaises(ValueError): memory_ledger('4b',n)
        with self.assertRaises(ValueError): cloud_budget('nan',1)
    def test_h200_ten_hour_allocation(self):
        r=cloud_budget('5.29','10',noncompute='10',tax_rate='0.1')
        self.assertTrue(r['allowed_by_planning_limits'])
        self.assertEqual(r['new_compute_usd'],'52.90')
        self.assertEqual(r['projected_all_in_usd'],'69.19')
    def test_total_budget_rejects(self):
        self.assertFalse(cloud_budget('5.29','20')['allowed_by_planning_limits'])
    def test_prior_spend_counts(self):
        self.assertFalse(cloud_budget('5.29','10',prior_compute='25')['allowed_by_planning_limits'])
    def test_tax_reserve(self):
        self.assertFalse(cloud_budget('1','70',noncompute='10',tax_rate='0.1')['allowed_by_planning_limits'])

if __name__=='__main__': unittest.main(verbosity=2)
