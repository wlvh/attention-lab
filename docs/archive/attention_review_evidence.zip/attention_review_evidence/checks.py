"""CPU mechanism checks; no Qwen weights, no language or GPU benchmark.
Run: python checks.py
Requires: torch, numpy. Writes checks.json next to this script.
"""
from pathlib import Path
import json, math, platform
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F


def main():
    torch.set_num_threads(1)
    torch.manual_seed(7)
    # An isolated attention head, not a complete pretrained language model.
    base = nn.ModuleDict({n: nn.Linear(16, 8, bias=False) for n in ('q','k','v')})
    base.requires_grad_(False)
    idx = nn.ModuleDict({n: nn.Linear(8, 4, bias=False) for n in ('q','k')})
    x = torch.randn(16, 12, 16)
    with torch.no_grad():
        q,k,v = (base[n](x) for n in ('q','k','v'))
        teacher = (q @ k.transpose(-1,-2)/math.sqrt(8)).softmax(-1)
        original_output = teacher @ v
    frozen_before = {n: p.detach().clone() for n,p in base.named_parameters()}
    index_before = {n: p.detach().clone() for n,p in idx.named_parameters()}
    def logits():
        return idx['q'](q) @ idx['k'](k).transpose(-1,-2) / 2
    def loss_fn():
        return F.kl_div(logits().log_softmax(-1), teacher, reduction='none').sum(-1).mean()
    initial = loss_fn().item()
    opt = torch.optim.AdamW(idx.parameters(), lr=0.02)
    for _ in range(250):
        opt.zero_grad(set_to_none=True)
        loss = loss_fn()
        loss.backward()
        opt.step()
    final = loss_fn().item()
    assert final < initial
    frozen_changed = sum(not torch.equal(p, frozen_before[n]) for n,p in base.named_parameters())
    index_changed = sum(not torch.equal(p, index_before[n]) for n,p in idx.named_parameters())
    with torch.no_grad():
        q2,k2,v2 = (base[n](x) for n in ('q','k','v'))
        dense_after = (q2 @ k2.transpose(-1,-2)/math.sqrt(8)).softmax(-1) @ v2
    assert frozen_changed == 0 and index_changed == 2
    assert torch.equal(original_output, dense_after)
    # Only integer top-k indices connect the indexer to the answer path.
    # V is made trainable purely to keep this probe's answer graph differentiable.
    choices = logits().topk(3, dim=-1).indices
    vp = v.clone().requires_grad_()
    b,qn,_=choices.shape
    ki = k[:,None,:,:].expand(-1,qn,-1,-1).gather(2, choices[:,:,:,None].expand(-1,-1,-1,8))
    vi = vp[:,None,:,:].expand(-1,qn,-1,-1).gather(2, choices[:,:,:,None].expand(-1,-1,-1,8))
    sparse = (((q[:,:,None,:]*ki).sum(-1)/math.sqrt(8)).softmax(-1)[:,:,:,None]*vi).sum(2)
    grads = torch.autograd.grad(sparse.square().mean(), tuple(idx.parameters()), allow_unused=True)
    assert all(g is None for g in grads)
    output_change = (sparse.detach()-original_output).abs().max().item()
    assert output_change > 1e-6
    def rot(t):
        return np.array([[math.cos(t),-math.sin(t)],[math.sin(t),math.cos(t)]])
    u=np.array([1.,0.]); P=np.array([[1.,0.]])
    rope_full=[float((rot(a)@u)@(rot(a)@u)) for a in (0.,math.pi/2)]
    rope_proj=[float(((P@rot(a)@u)*(P@rot(a)@u)).sum()) for a in (0.,math.pi/2)]
    assert abs(rope_full[0]-rope_full[1])<1e-12
    assert abs(rope_proj[0]-rope_proj[1])>0.9
    # Byte-to-time scenarios: NOT measured HBM traffic or a latency forecast.
    traffic=[]
    for model,L in [('0.6B',28),('4B',36)]:
        for N in (8192,16384,32768):
            selected=1024+4+64
            kv=2*L*N*8*128*2
            index=L*N*8*32*2
            sel=2*L*selected*8*128*2
            minimum=index+sel
            materialized=index+3*sel  # read old, write gather buffer, read buffer
            traffic.append(dict(model=model,N=N,kv_GB=kv/1e9,index_GB=index/1e9,
               selected_GB=sel/1e9,min_payload_GB=minimum/1e9,
               materialized_no_cache_payload_GB=materialized/1e9,
               min_payload_saving_ms_at_716_8=(kv-minimum)/716.8e9*1e3,
               materialized_saving_ms_at_716_8=(kv-materialized)/716.8e9*1e3))
    report={
       'scope':'CPU isolated-attention numerical checks; not pretrained Qwen, task quality or GPU timing',
       'environment':{'python':platform.python_version(),'torch':torch.__version__,'device':'CPU'},
       'frozen_parameter_tensors_changed':frozen_changed,
       'index_parameter_tensors_changed':index_changed,
       'index_parameter_count':sum(p.numel() for p in idx.parameters()),
       'initial_KL_same_training_features':initial,'final_KL_same_training_features':final,
       'dense_output_unchanged':torch.equal(original_output,dense_after),
       'sparse_vs_dense_max_abs':output_change,
       'answer_loss_grad_through_integer_topk_indices':[g is not None for g in grads],
       'same_position_shift_full_dot':rope_full,'same_position_shift_projected_dot':rope_proj,
       'traffic_scenarios':traffic,
       'traffic_scope':'Unique KV-group records read once in minimum-payload model. Materialized model assumes gather writes and subsequent reads reach main device memory. Neither includes score buffers, top-k passes, output/logits, allocator work, launch cost, or measured cache effects.'}
    path=Path(__file__).with_name('checks.json')
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
