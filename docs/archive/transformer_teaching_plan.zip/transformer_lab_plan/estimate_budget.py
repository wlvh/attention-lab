#!/usr/bin/env python3
"""Analytical budgeting for the proposed teaching model; NOT a speed benchmark.

Standard library only. Example:
  python estimate_budget.py --config lab_config.json
  python estimate_budget.py --config lab_config.json --positions-per-second 5000 \
      --extra-hours 2 --extra-watts 200 --yuan-per-kwh 1
The second example's inputs must be replaced with YOUR measured/actual values.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path


def positive(value: str) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError('Must be a positive, finite number.')
    return number


def nonnegative(value: str) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise argparse.ArgumentTypeError('Must be a nonnegative, finite number.')
    return number


def count_parameters(c: dict) -> dict[str, int]:
    names = ('vocab_size', 'layers', 'd_model', 'q_heads', 'kv_heads', 'head_dim', 'd_ff')
    for name in names:
        if type(c.get(name)) is not int or c[name] <= 0:
            raise ValueError(f'{name} must be a positive integer')
    v, l, d, h, hk, dh, f = (c[name] for name in names)
    if d != h * dh or h % hk != 0 or dh % 2 != 0:
        raise ValueError('Invalid GQA/RoPE dimensions')
    if c.get('linear_bias', False) or c.get('tie_embeddings', False):
        raise ValueError('This estimator assumes no linear biases and untied embeddings')
    return {
        'token_embedding': v*d,
        'q_projection': l*d*h*dh,
        'k_projection': l*d*hk*dh,
        'v_projection': l*d*hk*dh,
        'o_projection': l*h*dh*d,
        'two_matrix_ffn': l*2*d*f,
        'rmsnorm_learned_gains': (2*l+1)*d,
        'output_projection': v*d,
    }


def estimate(cfg: dict, args: argparse.Namespace) -> dict:
    c = cfg['model']
    parts = count_parameters(c)
    p = sum(parts.values())
    b = cfg['training']['batch_size']
    t = cfg['model']['training_sequence_limit']
    s = 4  # FP32 throughout the baseline.
    per_position = 2*c['layers']*c['kv_heads']*c['head_dim']*s
    positions = cfg['budget']['total_training_input_positions_cap']
    hours_cap = cfg['budget']['total_device_hours_cap']
    out = {
        'status': 'Analytical design estimates; no training or hardware speed was measured.',
        'parameter_breakdown': parts,
        'parameters': p,
        'fp32_weights_MiB': p*s/2**20,
        'fp32_weights_gradients_two_adam_moments_MiB': p*16/2**20,
        'kv_bytes_per_processed_position_per_request': per_position,
        'kv_payload_at_training_length_per_request_KiB': per_position*t/2**10,
        'kv_payload_at_training_length_batch_MiB': per_position*t*b/2**20,
        'one_dense_attention_score_matrix_MiB': b*c['q_heads']*t*t*s/2**20,
        'training_input_positions_cap': positions,
        'device_hours_cap': hours_cap,
        'memory_warning': 'Payloads are NOT total training/inference peak memory. Activations, workspaces, temporary GQA expansion, allocator and driver memory are additional.',
        'estimated_total_hours': None,
        'estimated_electricity_yuan': None,
    }
    if args.positions_per_second is not None:
        if args.extra_hours is None:
            raise ValueError('--positions-per-second also requires --extra-hours (validation, intervention and benchmarking budget)')
        total_hours = positions / args.positions_per_second / 3600 + args.extra_hours
        out['estimated_total_hours'] = total_hours
        out['within_device_hours_cap'] = total_hours <= hours_cap
        out['throughput_warning'] = 'Use completed forward+backward+optimizer steps plus data loading, not inference throughput or device peak FLOPS.'
    if (args.extra_watts is None) != (args.yuan_per_kwh is None):
        raise ValueError('Provide --extra-watts and --yuan-per-kwh together')
    if args.extra_watts is not None:
        billed_hours = out['estimated_total_hours']
        if billed_hours is None:
            billed_hours = hours_cap
        out['electricity_hours_basis'] = billed_hours
        out['estimated_electricity_yuan'] = billed_hours * args.extra_watts/1000 * args.yuan_per_kwh
        out['electricity_warning'] = 'Scenario/input-based electricity only, excluding hardware, idle baseline, labor, subscriptions and cloud.'
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=Path(__file__).with_name('lab_config.json'))
    parser.add_argument('--positions-per-second', type=positive)
    parser.add_argument('--extra-hours', type=nonnegative)
    parser.add_argument('--extra-watts', type=nonnegative)
    parser.add_argument('--yuan-per-kwh', type=nonnegative)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        cfg = json.loads(args.config.read_text(encoding='utf-8'))
        result = estimate(cfg, args)
        text = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(text, encoding='utf-8')
        print(text, end='')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.exit(2, f'Budget error: {exc}\n')


if __name__ == '__main__':
    main()
